# spreadsheet_controller_adapter.py
"""把我们自己的 Spreadsheet 封装成老师接口"""

from usecasesmarker.spreadsheet_controller_for_checker import ISpreadsheetControllerForChecker


class StudentSpreadsheetController(ISpreadsheetControllerForChecker):
    def __init__(self):
        # 延迟导入，避免循环引用
        from umlspreadsheet.spreadsheet import Spreadsheet
        from umlspreadsheet.formula_processor import FormulaProcessor

        self.sheet = Spreadsheet()
        self.fp = FormulaProcessor()

    # ============== setters ==============
    def set_cell_content(self, coordinate: str, content) -> None:
        from umlspreadsheet.ast.operand import Numeric, Text

        # -------- 非字符串：直接数值 --------
        if not isinstance(content, str):
            self.sheet.set_cell(coordinate, Numeric(content))
            return

        # -------- 公式 --------
        if content.startswith("="):
            expr = content[1:]                                 # 去掉 '='
            toks = self.fp.tokenize(expr)                      # 已将 ;→, 兼容西语
            postfix = self.fp.parse(toks)

            # 带 evaluate 的公式内容对象
            class FormulaContent(list):
                def __init__(self, raw: str, pf_tokens: list, fp):
                    super().__init__(pf_tokens)                # list 本身就是后缀表达式
                    self.raw_text = raw
                    self._fp = fp                              # 单下划线，避免名字改写

                def evaluate(self, ctx):
                    return self._fp.evaluate(self, ctx)

            self.sheet.set_cell(coordinate,
                                FormulaContent(content, postfix, self.fp))
            return

        # -------- 普通字符串 --------
        try:
            num = float(content)
            self.sheet.set_cell(coordinate, Numeric(num))
        except ValueError:
            self.sheet.set_cell(coordinate, Text(content))

    # ============== getters ==============
    def _value(self, coord: str):
        return self.sheet.get_cell(coord).get_value()

    def get_cell_content_as_string(self, coordinate: str) -> str:
        val = self._value(coordinate)
        return "" if val in ("", None) else str(val)

    def get_cell_content_as_float(self, coordinate: str) -> float:
        val = self._value(coordinate)
        try:
            return float(val)
        except (ValueError, TypeError):
            return 0.0

    def get_cell_formula_expression(self, coordinate: str) -> str:
        cell = self.sheet.get_cell(coordinate)
        return getattr(cell.content, "raw_text", "")

    # ============== I/O ==============
    def save_spreadsheet_to_file(self, filename: str) -> None:
        from umlspreadsheet.storage import save_s2v
        save_s2v(self.sheet, filename)

    def load_spreadsheet_from_file(self, filename: str) -> None:
        from umlspreadsheet.storage import load_s2v
        self.sheet = load_s2v(filename)
