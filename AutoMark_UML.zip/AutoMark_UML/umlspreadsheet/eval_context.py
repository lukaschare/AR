from __future__ import annotations
from typing import Any, TYPE_CHECKING
from .utils import parse_coord, idx_to_col

if TYPE_CHECKING:
    from .spreadsheet import Spreadsheet

class EvalContext:
    def __init__(self, sheet: Spreadsheet):
        self.sheet = sheet

    def get_cell_value(self, coord: str) -> Any:
        return self.sheet.get_cell(coord).get_value()

    def get_range_values(self, start: str, end: str):
        r1, c1 = parse_coord(start)
        r2, c2 = parse_coord(end)
        values = []
        for r in range(min(r1, r2), max(r1, r2) + 1):
            for c in range(min(c1, c2), max(c1, c2) + 1):
                coord = f"{idx_to_col(c)}{r + 1}"
                values.append(self.get_cell_value(coord))
        return values