
# umlspreadsheet/function_type.py
from enum import Enum, auto


class FunctionType(Enum):
    # —— 算术 / 聚合 ——
    SUM = auto()
    SUMA = auto()         # 西语 SUM（老师测试用）
    AVERAGE = auto()
    PROMEDIO = auto()     # 西语 AVERAGE
    MIN = auto()
    MAX = auto()
    COUNT = auto()

    # —— 其它函数 ——
    IF = auto()
    ROUND = auto()
    ABS = auto()
    SQRT = auto()
    LOG = auto()
    EXP = auto()
