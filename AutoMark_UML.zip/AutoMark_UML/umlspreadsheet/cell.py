from dataclasses import dataclass
from .cell_content import CellContent
from typing import Any

@dataclass
class Cell:
    coordinate: str
    content: CellContent | None = None
    _ctx = None  # 运行时注入 (EvalContext)

    def set_content(self, content: CellContent):
        self.content = content

    def get_value(self) -> Any:
        if self.content is None:
            return ""
        return self.content.evaluate(self._ctx)