# -*- coding: utf-8 -*-
"""
Shunting-yard 算法 ➜ 后缀表达式 (RPN) ➜ 计算
"""
from __future__ import annotations
from typing import Any

from .tokenizer import Token, TokenType, tokenize
from .exceptions import SyntaxFormulaException
from .ast.operand import Numeric, Text, CellReference
from .ast.range import Range
from .ast.function import Function, func_from_name
from .ast.operator import Operator

class FormulaProcessor:
    # --------------------------------------------------
    # public helpers
    # --------------------------------------------------
    def tokenize(self, formula: str) -> list[Token]:
        return tokenize(formula.replace(",", ";"))

    # --------------------------------------------------
    # PARSE : tokens -> RPN list
    # --------------------------------------------------
    def parse(self, toks: list[Token]) -> list[Any]:
        output: list[Any] = []
        op_stack: list[Token] = []

        def flush_until(pred):
            while op_stack and pred(op_stack[-1]):
                tok = op_stack.pop()
                if tok.type == TokenType.FUNCTION:
                    raise SyntaxFormulaException("Function mis-placement")
                output.append(tok.obj)

        i = 0
        while i < len(toks):
            tok = toks[i]
            tt = tok.type
            if tt == TokenType.NUMBER:
                output.append(Numeric(tok.obj))
            elif tt == TokenType.STRING:
                output.append(Text(tok.obj))
            elif tt == TokenType.CELL:
                output.append(CellReference(tok.text))
            elif tt == TokenType.RANGE:
                s, e = tok.text.split(":")
                output.append(Range(s, e))
            elif tt == TokenType.FUNCTION:
                op_stack.append(tok)
            elif tt == TokenType.SEP:
                # flush until '('
                # flush_until(lambda t: t.type != TokenType.LPAREN)
                # 参数分隔符 —— 在输出序列里放一个哨兵
                # 后面收集实参时据此切分
                flush_until(lambda t: t.type != TokenType.LPAREN)
                output.append(_ArgBoundary())  # <── 新增
            elif tt == TokenType.OPERATOR:
                flush_until(
                    lambda t: t.type == TokenType.OPERATOR and
                    (t.obj.precedence > tok.obj.precedence or
                     (t.obj.precedence == tok.obj.precedence and tok.obj.left_assoc))
                )
                op_stack.append(tok)
            elif tt == TokenType.LPAREN:
                op_stack.append(tok)
            elif tt == TokenType.RPAREN:
                flush_until(lambda t: t.type != TokenType.LPAREN)
                if not op_stack or op_stack[-1].type != TokenType.LPAREN:
                    raise SyntaxFormulaException("Mismatched parenthesis")
                op_stack.pop()          # discard '('
                if op_stack and op_stack[-1].type == TokenType.FUNCTION:
                    func_tok = op_stack.pop()
                    # collect args since last '(' or SEP
                    args: list[Any] = []
                    # while output and not isinstance(output[-1], _ArgBoundary):
                    while output and not isinstance(output[-1], _ArgBoundary):
                        args.insert(0, output.pop())
                    # if output and isinstance(output[-1], _ArgBoundary):
                    #     output.pop()
                    if output and isinstance(output[-1], _ArgBoundary):
                        output.pop()  # 丢弃边界哨兵
                    output.append(Function(func_from_name(func_tok.text), args))
            elif tt == TokenType.EOF:
                break
            else:
                raise SyntaxFormulaException(f"Unexpected token {tok!r}")
            i += 1

        # 剩余全部弹出
        while op_stack:
            t = op_stack.pop()
            if t.type in (TokenType.LPAREN, TokenType.RPAREN):
                raise SyntaxFormulaException("Mismatched parenthesis")
            output.append(t.obj)
        return output

    # --------------------------------------------------
    # EVAL : RPN list -> value
    # --------------------------------------------------
    def evaluate(self, postfix: list[Any], ctx):
        stack: list[Any] = []
        for item in postfix:
            if isinstance(item, (Numeric, Text, CellReference, Range, Function)):
                stack.append(item.evaluate(ctx))
            elif isinstance(item, Operator):
                # if item is Operator.NOT:          # 一元
                #     a = stack.pop()
                #     stack.append(item.evaluate(ctx, a))
                # else:

                if item is Operator.NOT:  # 一元
                    a = stack.pop()
                    stack.append(item.evaluate(ctx, a, None))
                else:
                    b = stack.pop()
                    a = stack.pop()
                    stack.append(item.evaluate(ctx, a, b))
            else:
                raise RuntimeError(f"Unknown AST node {item!r}")
        if len(stack) != 1:
            raise SyntaxFormulaException("Malformed expression")
        return stack[0]

# --------------------------------------------------
# 内部辅助：函数参数分隔占位
# --------------------------------------------------
class _ArgBoundary: ...
