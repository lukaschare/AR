# umlspreadsheet/token.py
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
from typing import Any


class TokenType(Enum):
    NUMBER   = auto()   # 123, 4.56
    STRING   = auto()   # "hello"
    CELL     = auto()   # A1, B12
    RANGE    = auto()   # A1:B7
    FUNCTION = auto()   # SUM, SUMA, PROMEDIO, ...
    OPERATOR = auto()   # + - * / ^ = > < >= <= != AND OR NOT
    SEP      = auto()   # 参数分隔符 ;   （西语公式）
    LPAREN   = auto()   # (
    RPAREN   = auto()   # )
    EOF      = auto()   # 结束标记


@dataclass
class Token:
    """
    词法分析得到的 token。
    - type: TokenType
    - text: 源字符串
    - obj : 解析后的对象（可选）。后续语法分析阶段把它放进来，
            例如把 NUMBER 解析成 float，CELL 解析成 'A1' 等。
    """
    type: TokenType
    text: str
    obj: Any | None = None

    # 允许后续阶段写入 obj，所以绝不能 frozen=True
    def __repr__(self) -> str:          # 便于调试
        return f"Token({self.type.name}, {self.text!r}, obj={self.obj!r})"
