from abc import ABC, abstractmethod
from .eval_context import EvalContext

class CellContent(ABC):
    """顶层抽象——数值/文本/公式都实现 evaluate"""

    @abstractmethod
    def evaluate(self, context: EvalContext): ...