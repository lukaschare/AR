import re
from .exceptions import BadCoordinateException

_RE = re.compile(r"^([A-Z]+)([1-9]\d*)$")

# 列字母 ↔ 索引

def col_to_idx(col: str) -> int:
    idx = 0
    for ch in col:
        idx = idx * 26 + (ord(ch) - 64)
    return idx - 1

def idx_to_col(idx: int) -> str:
    idx += 1
    name = ""
    while idx:
        idx, r = divmod(idx - 1, 26)
        name = chr(65 + r) + name
    return name

# 解析 "A1" → (row_idx, col_idx)

def parse_coord(coord: str) -> tuple[int, int]:
    m = _RE.match(coord.upper())
    if not m:
        raise BadCoordinateException(coord)
    col, row = m.groups()
    return int(row) - 1, col_to_idx(col)