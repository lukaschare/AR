from .spreadsheet import Spreadsheet
def create_spreadsheet() -> Spreadsheet:
    return Spreadsheet()
