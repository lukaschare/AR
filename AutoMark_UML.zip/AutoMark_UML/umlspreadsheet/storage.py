"""
Very small S2V (Spread-to-Value) persistence layer.
The format expected by the marker:

- one spreadsheet row per line
- odd columns are coordinates (e.g. A1), even columns are the
  *raw* content (number, text, or formula string beginning with '=')
- columns separated by ';'
- completely empty spreadsheet row → empty line
"""
from __future__ import annotations
from pathlib import Path
from typing import List

from .spreadsheet import Spreadsheet
from .exceptions import SavingSpreadSheetException, ReadingSpreadSheetException
from .ast.operand import Numeric, Text
from .formula_processor import FormulaProcessor


def _coord(col_idx: int, row_idx: int) -> str:
    col = ""
    while col_idx:
        col_idx, rem = divmod(col_idx - 1, 26)
        col = chr(65 + rem) + col
    return f"{col}{row_idx}"


# ---------- saving ----------
def save_s2v(sheet: Spreadsheet, filename: str) -> None:
    """Serialise current spreadsheet to a .s2v file."""
    try:
        # max_row = sheet.max_row()
        # max_col = sheet.max_col()
        max_row = sheet.max_row()
        max_col = sheet.max_col()  # 需要 Spreadsheet.max_col 已实现
        lines: List[str] = []

        for r in range(1, max_row + 1):
            parts: List[str] = []
            for c in range(1, max_col + 1):
                coord = _coord(c, r)
                cell = sheet.get_cell(coord)
                if cell.is_empty():
                    continue
                parts.append(coord)
                parts.append(cell.raw_text() if cell.is_formula()
                             else str(cell.get_value()))
            lines.append(";".join(parts))
        Path(filename).write_text("\n".join(lines), encoding="utf8")
    except Exception as exc:
        raise SavingSpreadSheetException(str(exc)) from exc


# ---------- loading ----------
def load_s2v(filename: str) -> Spreadsheet:
    """Read .s2v file and rebuild a Spreadsheet."""
    fpz = FormulaProcessor()
    try:
        sheet = Spreadsheet()
        for row_str in Path(filename).read_text(encoding="utf8").splitlines():
            if not row_str.strip():
                continue        # blank row
            parts = row_str.split(";")
            if len(parts) % 2 != 0:
                raise ReadingSpreadSheetException("Bad column count")
            for coord, raw in zip(parts[0::2], parts[1::2]):
                if not raw:
                    continue
                if raw.startswith("="):
                    toks = fpz.tokenize(raw)
                    postfix = fpz.parse(toks)
                    # postfix.raw_text = raw         # for persistence
                    sheet.set_cell(coord, postfix)
                else:
                    try:
                        num = float(raw)
                        sheet.set_cell(coord, Numeric(num))
                    except ValueError:
                        sheet.set_cell(coord, Text(raw))
        return sheet
    except Exception as exc:
        raise ReadingSpreadSheetException(str(exc)) from exc
