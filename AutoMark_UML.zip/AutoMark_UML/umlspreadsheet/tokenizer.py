# -*- coding: utf-8 -*-
"""
把公式字符串 → Token 列表，并且 **在这里就把 token.obj 填好**，
后续 parse 不再补全，能彻底消除 None 问题。
"""
from __future__ import annotations
import re
import string
from dataclasses import dataclass
from typing import Iterator

from .ast.operator import Operator   # 直接用枚举

class TokenType:
    NUMBER    = "NUMBER"
    STRING    = "STRING"
    CELL      = "CELL"
    RANGE     = "RANGE"
    FUNCTION  = "FUNCTION"
    OPERATOR  = "OPERATOR"
    SEP       = "SEP"          # 函数参数 ‘;’
    LPAREN    = "LPAREN"
    RPAREN    = "RPAREN"
    EOF       = "EOF"

@dataclass(frozen=True, slots=True)
class Token:
    type: str
    text: str
    obj: object | None = None      # 已解析的对象（float / str / Operator …）

_SPEC = [
    (TokenType.NUMBER,   r'\d+(\.\d+)?'),
    (TokenType.STRING,   r'"[^"]*"'),
    (TokenType.RANGE,    r'[A-Z]+[0-9]+:[A-Z]+[0-9]+'),
    (TokenType.CELL,     r'[A-Z]+[0-9]+'),
    (TokenType.FUNCTION, r'[A-Za-z_]+\b'),
    (TokenType.OPERATOR, r'<>|>=|<=|!=|[\+\-\*/\^=><]'),
    (TokenType.SEP,      r';'),
    (TokenType.LPAREN,   r'\('),
    (TokenType.RPAREN,   r'\)'),
    (None,               r'\s+'),
]
_REGEX = re.compile(
    '|'.join(f'(?P<{t or "SKIP"}>{p})' for t, p in _SPEC)
)

def _make_token(ttype: str, txt: str) -> Token:
    if ttype == TokenType.NUMBER:
        return Token(ttype, txt, float(txt))
    if ttype == TokenType.STRING:
        return Token(ttype, txt, txt[1:-1])
    if ttype == TokenType.OPERATOR:
        return Token(ttype, txt, Operator(txt.upper()))
    # CELL / RANGE / FUNCTION -> 先统一大写
    return Token(ttype, txt.upper())

def tokenize(formula: str) -> list[Token]:
    pos = 0
    tokens: list[Token] = []
    while pos < len(formula):
        m = _REGEX.match(formula, pos)
        if not m:
            raise ValueError(f"Unexpected char: {formula[pos]!r}")
        kind = m.lastgroup
        text = m.group(kind)
        pos = m.end()
        if kind == "SKIP":
            continue
        tokens.append(_make_token(kind, text))
    tokens.append(Token(TokenType.EOF, ""))
    return tokens
