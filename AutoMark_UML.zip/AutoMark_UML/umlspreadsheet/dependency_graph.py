"""维护 cell → dependents 反向邻接表，支持环检测与拓扑更新"""
from collections import defaultdict, deque
from typing import Dict, Set, List
from .exceptions import CircularReferenceException

class DependencyGraph:
    def __init__(self):
        self._graph: Dict[str, Set[str]] = defaultdict(set)   # a -> {b,c} : a 被哪些依赖
        self._forward: Dict[str, Set[str]] = defaultdict(set) # a -> {b,c} : a 依赖谁

    def set_dependencies(self, cell: str, deps: Set[str]):
        # 先移除旧 forward 边
        for d in self._forward.get(cell, set()):
            self._graph[d].discard(cell)
        # 更新
        self._forward[cell] = deps
        for d in deps:
            self._graph[d].add(cell)
        # 检测环
        if self._has_cycle():
            raise CircularReferenceException(f"Circular dependency involving {cell}")

    def get_dependents(self, cell: str) -> Set[str]:
        return self._graph.get(cell, set())

    # —— internal ——
    def _has_cycle(self):
        # Kahn 拓扑
        indeg: Dict[str, int] = {}
        for v in self._forward:
            indeg[v] = indeg.get(v, 0)
            for w in self._forward[v]:
                indeg[w] = indeg.get(w, 0) + 1
        dq = deque([v for v, deg in indeg.items() if deg == 0])
        visited = 0
        while dq:
            v = dq.popleft()
            visited += 1
            for w in self._forward.get(v, set()):
                indeg[w] -= 1
                if indeg[w] == 0:
                    dq.append(w)
        return visited != len(indeg)