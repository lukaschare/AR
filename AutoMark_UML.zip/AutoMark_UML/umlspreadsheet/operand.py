# umlspreadsheet/ast/operand.py
from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any
from ..eval_context import EvalContext

class Operand(ABC):
    @abstractmethod
    def evaluate(self, ctx: EvalContext) -> Any: ...

# ---------- 单值 ----------
@dataclass
class Numeric(Operand):
    number: float
    def __str__(self) -> str:         # 供存盘输出
        return str(self.number)
    def evaluate(self, ctx: EvalContext):
        return self.number

@dataclass
class Text(Operand):
    text: str
    def __str__(self) -> str:         # 供存盘输出
        return self.text
    def evaluate(self, ctx: EvalContext):
        return self.text

# ---------- 引用 ----------
@dataclass
class CellReference(Operand):
    coordinate: str
    def evaluate(self, ctx: EvalContext):
        return ctx.get_cell_value(self.coordinate)

@dataclass
class Range(Operand):
    start: str
    end: str
    def evaluate(self, ctx: EvalContext):
        return ctx.get_range_values(self.start, self.end)
