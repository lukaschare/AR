# umlspreadsheet/spreadsheet.py

from __future__ import annotations
from typing import Dict, Set
from .cell import Cell
from .eval_context import EvalContext
from .dependency_graph import DependencyGraph
from .exceptions import SyntaxFormulaException

class Spreadsheet:
    def __init__(self):
        self._cells: Dict[str, Cell] = {}
        self._deps = DependencyGraph()
        self._ctx = EvalContext(self)

    def get_cell(self, coordinate: str) -> Cell:
        """
        Return a Cell object for the given coordinate, creating it if necessary.
        Injects the shared EvalContext into the cell before returning.
        """
        cell = self._cells.setdefault(coordinate, Cell(coordinate))
        cell._ctx = self._ctx
        return cell

    def set_cell(self, coordinate: str, content) -> None:
        """
        Set the content of the cell at `coordinate` (which may be a formula postfix list,
        a Numeric/Text operand, etc.), then update dependencies and recalculate dependents.
        """
        cell = self.get_cell(coordinate)
        cell.set_content(content)

        # Extract dependencies from the new content and update the graph
        deps = self._extract_dependencies(content)
        self._deps.set_dependencies(coordinate, deps)

        # Recompute all dependent cells in topological order
        self._update_dependents(coordinate)

    def _extract_dependencies(self, content) -> Set[str]:
        """
        Walk the content (which may be a formula's postfix list or Operand tree)
        to collect all cell references that this content depends on.
        """
        # from .ast.operand import CellReference, Range
        from .ast.operand import CellReference
        from .ast.range import Range

        from .ast.function import Function

        refs: Set[str] = set()

        def walk(node):
            if isinstance(node, CellReference):
                refs.add(node.coordinate)
            elif isinstance(node, Range):
                refs.add(node.start)
                refs.add(node.end)
            elif isinstance(node, Function):
                for arg in node.args:
                    walk(arg)
            elif hasattr(node, "args"):
                # Some postfix lists embed Functions with .args
                for a in node.args:
                    walk(a)
            elif hasattr(node, "operands"):
                # Component nodes carry .operands
                for o in node.operands:
                    walk(o)

        walk(content)
        return refs

    # ---------- storage.save_s2v 需要 ----------
    def max_row(self) -> int:
        """返回当前工作表已使用的最大行号（1-based）。空表返 0。"""
        if not self._cells:
            return 0
        from .utils import parse_coord          # 行/列解析工具
        return max(parse_coord(c)[0] for c in self._cells)

    def max_col(self) -> int:
        """返回当前工作表已使用的最大列号（1-based）。空表返 0。"""
        if not self._cells:
            return 0
        from .utils import parse_coord       # col 索引解析
        return max(parse_coord(c)[1] for c in self._cells)

    def max_col(self) -> int:
        """返回当前工作表已使用的最大列号（1-based）。空表返 0。"""
        if not self._cells:
            return 0
        from .utils import parse_coord
        return max(parse_coord(c)[1] for c in self._cells)

    def _update_dependents(self, coord: str) -> None:
        """
        Starting from the changed cell `coord`, perform a breadth-first traversal
        of the dependency graph to recompute each dependent cell.
        """
        visited = {coord}
        queue = [coord]
        while queue:
            current = queue.pop(0)
            for dep in self._deps.get_dependents(current):
                if dep in visited:
                    continue
                visited.add(dep)
                cell = self.get_cell(dep)
                # Trigger evaluation by getting its value
                _ = cell.get_value()
                queue.append(dep)

    def __str__(self) -> str:
        """
        Return a simple textual representation of the sheet's non-empty cells,
        row by row, tab-separated.
        """
        if not self._cells:
            return "<empty sheet>"

        from .utils import parse_coord, idx_to_col

        rows: Dict[int, Dict[int, str]] = {}
        for coord in self._cells:
            r, c = parse_coord(coord)
            rows.setdefault(r, {})[c] = str(self.get_cell(coord).get_value())

        lines = []
        for r in sorted(rows):
            cols = rows[r]
            line = "\t".join(cols.get(c, "") for c in sorted(cols))
            lines.append(line)

        return "\n".join(lines)
