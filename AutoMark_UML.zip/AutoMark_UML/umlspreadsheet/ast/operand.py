# -*- coding: utf-8 -*-
from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any
from ..eval_context import EvalContext

class Operand(ABC):
    """所有 AST 结点共同接口"""
    @abstractmethod
    def evaluate(self, ctx: EvalContext) -> Any: ...

@dataclass(slots=True)
class Numeric(Operand):
    value: float
    def evaluate(self, ctx: EvalContext) -> float:
        return self.value

@dataclass(slots=True)
class Text(Operand):
    value: str
    def evaluate(self, ctx: EvalContext) -> str:
        return self.value

@dataclass(slots=True)
class CellReference(Operand):
    coord: str
    def evaluate(self, ctx: EvalContext) -> Any:
        return ctx.get_cell_value(self.coord)
