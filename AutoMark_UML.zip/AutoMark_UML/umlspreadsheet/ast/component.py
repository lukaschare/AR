"""Component 代表一个完整的中缀公式。这里不再做求值，
而是交给 FormulaProcessor 生成的后缀 token 执行。"""
from dataclasses import dataclass
from typing import List
from .operand import Operand
from ..operator import Operator

@dataclass
class Component:
    operands: List[Operand]
    operators: List[Operator]
    # 仅为保留 UML 结构所用；真正求值不依赖该类。