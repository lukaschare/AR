# File: umlspreadsheet/ast/function.py
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, List

from ..function_type import FunctionType
from .operand  import Operand, Numeric, Text, CellReference          # 基本操作数
from .range    import Range                                          # 区域
from .operator import Operator                                       # 运算符
from ..eval_context      import EvalContext

# ---------- 名称 → FunctionType ----------
def func_from_name(name: str) -> FunctionType:
    n = name.strip().upper()
    if n in ("SUMA", "SUM"):                 return FunctionType.SUM
    if n in ("PROMEDIO", "AVERAGE"):         return (FunctionType.PROMEDIO
                                                    if n == "PROMEDIO"
                                                    else FunctionType.AVERAGE)
    if n == "MIN":    return FunctionType.MIN
    if n == "MAX":    return FunctionType.MAX
    if n == "COUNT":  return FunctionType.COUNT
    if n == "IF":     return FunctionType.IF
    if n == "ROUND":  return FunctionType.ROUND
    if n == "ABS":    return FunctionType.ABS
    raise ValueError(f"Unknown function name '{name}'")

# ----------------- Function 节点 -----------------
@dataclass
class Function(Operand):
    name: FunctionType
    args: List[Operand]          # 解析阶段已经把参数打平成“后缀表达式”序列

    # ---- 运行时求值 ----
    def evaluate(self, ctx: EvalContext) -> Any:
        """
        self.args 本质是一段 _独立的后缀表达式_：
            • 可能是单个常量     → [Numeric(3)]
            • 也可能是 1, A1*B1, 2+3  → [Numeric(1), CellRef(A1), CellRef(B1),
                                           Operator.MULTIPLY, Numeric(2),
                                           Numeric(3), Operator.PLUS]
        先用一个栈把它求值得到 “扁平实参序列 flat”，然后
        按 FunctionType 折叠成最终结果。
        """
        # stack: list[Any] = []
        stack: list[Any] = []

        def push(v: Any):                # Range 会返回 list，需要展开
            if isinstance(v, list):
                stack.extend(v)
            else:
                stack.append(v)

        for node in self.args:
            if isinstance(node, (Numeric, Text, CellReference, Range, Function)):
                push(node.evaluate(ctx))

            elif isinstance(node, Operator):            # 二元运算
                try:
                    b = stack.pop()
                    a = stack.pop()
                except IndexError:
                    raise ValueError("Malformed expression inside function args")
                push(node.evaluate(ctx, a, b))

            else:                                       # 其它节点一律视为错误
                raise TypeError(f"Unsupported node in function args: {node!r}")

        flat = stack                # 此时 stack 正好就是全部实参值

        # ---------- 根据函数类型折叠 ----------
        if self.name == FunctionType.SUM:
            return sum(flat)

        if self.name in (FunctionType.AVERAGE, FunctionType.PROMEDIO):
            return (sum(flat) / len(flat)) if flat else 0.0

        if self.name == FunctionType.MIN:      return min(flat) if flat else 0.0
        if self.name == FunctionType.MAX:      return max(flat) if flat else 0.0
        if self.name == FunctionType.COUNT:    return len([v for v in flat if v != ""])

        if self.name == FunctionType.IF:       # IF(cond, then, else)
            cond, then_v, else_v = flat
            return then_v if cond else else_v

        if self.name == FunctionType.ROUND:    # ROUND(value, ndigits)
            value, ndigits = flat
            return round(value, int(ndigits))

        if self.name == FunctionType.ABS:
            return abs(flat[0]) if flat else 0.0

        raise NotImplementedError(f"Function '{self.name.name}' is not implemented")
