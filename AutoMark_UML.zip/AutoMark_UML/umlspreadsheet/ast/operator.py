from enum import Enum, auto

class Operator(str, Enum):
    PLUS = "+"
    MINUS = "-"
    MULTIPLY = "*"
    DIVIDE = "/"
    POWER = "^"
    EQUAL = "="
    NOT_EQUAL = "!="
    GT = ">"
    LT = "<"
    GE = ">="
    LE = "<="
    AND = "AND"
    OR = "OR"
    NOT = "NOT"

    @property
    def precedence(self) -> int:
        return {
            Operator.OR: 0,
            Operator.AND: 1,
            Operator.EQUAL: 2,
            Operator.NOT_EQUAL: 2,
            Operator.GE: 2,
            Operator.LE: 2,
            Operator.GT: 2,
            Operator.LT: 2,
            Operator.PLUS: 3,
            Operator.MINUS: 3,
            Operator.MULTIPLY: 4,
            Operator.DIVIDE: 4,
            Operator.POWER: 5,
            Operator.NOT: 6,
        }[self]

    @property
    def left_assoc(self) -> bool:
        return self not in {Operator.POWER, Operator.NOT}

    # `b` 为 None 时表示一元
    def evaluate(self, ctx, a, b=None):
        if self is Operator.NOT:
            return not bool(a)
        if self is Operator.PLUS:
            return a + b
        if self is Operator.MINUS:
            return a - b
        if self is Operator.MULTIPLY:
            return a * b
        if self is Operator.DIVIDE:
            return a / b
        if self is Operator.POWER:
            return a ** b
        if self is Operator.EQUAL:
            return a == b
        if self is Operator.NOT_EQUAL:
            return a != b
        if self is Operator.GT:
            return a > b
        if self is Operator.LT:
            return a < b
        if self is Operator.GE:
            return a >= b
        if self is Operator.LE:
            return a <= b
        if self is Operator.AND:
            return bool(a) and bool(b)
        if self is Operator.OR:
            return bool(a) or bool(b)
        raise NotImplementedError(self)
