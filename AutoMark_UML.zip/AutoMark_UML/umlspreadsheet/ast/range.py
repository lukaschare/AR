# File: umlspreadsheet/ast/range.py

from __future__ import annotations
from typing import List
from ..eval_context import EvalContext
from .operand import Operand     # 方便用 isinstance 检查

__all__ = ["Range"]

class Range(Operand):
    """
    表示一个连续区域，如 A1:B3
    在 evaluate 时遍历区域里所有单元格，返回 **一个 Python 列表**，
    后续函数（SUMA、MIN、MAX …）再根据需求把它们展开/折叠。
    """
    def __init__(self, start: str, end: str):
        self.start = start.upper()
        self.end = end.upper()

    # ----------------------------------------
    # helpers
    # ----------------------------------------
    @staticmethod
    def _coord_to_index(coord: str) -> tuple[int, int]:
        """把 A1 → (0,0) 这种行列 index；只支持到 ZZZ… 足够用了"""
        import string
        col = 0
        row_part = ""
        for ch in coord:
            if ch in string.ascii_letters:
                col = col * 26 + (ord(ch.upper()) - ord("A") + 1)
            else:
                row_part += ch
        return int(row_part) - 1, col - 1          # 0-based

    @staticmethod
    def _index_to_coord(row: int, col: int) -> str:
        """把 (0,0) → A1"""
        letters = ""
        col += 1                                   # 1-based
        while col:
            col, rem = divmod(col - 1, 26)
            letters = chr(rem + ord("A")) + letters
        return f"{letters}{row + 1}"

    # ----------------------------------------
    # core
    # ----------------------------------------
    def _all_coords(self) -> List[str]:
        r1, c1 = self._coord_to_index(self.start)
        r2, c2 = self._coord_to_index(self.end)
        if r1 > r2:
            r1, r2 = r2, r1
        if c1 > c2:
            c1, c2 = c2, c1
        return [
            self._index_to_coord(r, c)
            for r in range(r1, r2 + 1)
            for c in range(c1, c2 + 1)
        ]

    def evaluate(self, ctx: EvalContext):
        """返回区域内所有单元格的值（列表）"""
        return [ctx.get_cell_value(crd) for crd in self._all_coords()]
