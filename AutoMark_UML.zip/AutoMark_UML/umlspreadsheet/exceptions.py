# umlspreadsheet/exceptions.py

class SpreadsheetError(Exception):
    """根异常——所有工作簿相关错误的基类"""

class BadCoordinateException(SpreadsheetError):
    pass

class NoNumberException(SpreadsheetError):
    pass

class SyntaxFormulaException(SpreadsheetError):
    pass

class CircularReferenceException(SpreadsheetError):
    pass

# 以下两个异常类供 storage.py 使用
class ReadingSpreadSheetException(SpreadsheetError):
    """读取时的异常"""
    pass

class SavingSpreadSheetException(SpreadsheetError):
    """保存时的异常"""
    pass
