from enum import Enum

class Operator(str, Enum):
    # 算术
    PLUS = "+"
    MINUS = "-"
    MULTIPLY = "*"
    DIVIDE = "/"
    POWER = "^"
    # 比较
    EQUAL = "="
    NOT_EQUAL = "!="
    GT = ">"
    LT = "<"
    GE = ">="
    LE = "<="
    # 逻辑
    AND = "AND"
    OR = "OR"
    NOT = "NOT"

    @property
    def precedence(self) -> int:
        return {
            Operator.OR: 0,
            Operator.AND: 1,
            Operator.EQUAL: 2,
            Operator.NOT_EQUAL: 2,
            Operator.GE: 2,
            Operator.LE: 2,
            Operator.GT: 2,
            Operator.LT: 2,
            Operator.PLUS: 3,
            Operator.MINUS: 3,
            Operator.MULTIPLY: 4,
            Operator.DIVIDE: 4,
            Operator.POWER: 5,
            Operator.NOT: 6,  # 一元
        }[self]

    @property
    def left_assoc(self) -> bool:
        # 只有 POWER 右结合，其余左结合
        return self is not Operator.POWER