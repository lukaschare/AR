# from API.spreadsheet_controller_for_checker import ISpreadsheetControllerForChecker
from usecasesmarker.spreadsheet_controller_for_checker import ISpreadsheetControllerForChecker


from spreadsheet_controller_adapter import StudentSpreadsheetController

class SpreadSheetFactoryForChecker:  # 必须保持原名
    @staticmethod
    def create_spreadsheet_controller() -> ISpreadsheetControllerForChecker:
        return StudentSpreadsheetController()