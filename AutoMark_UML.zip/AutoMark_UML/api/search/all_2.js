var searchData=
[
  ['ispreadsheetcontrollerforchecker_0',['ISpreadsheetControllerForChecker',['../classusecasesmarker_1_1spreadsheet__controller__for__checker_1_1_i_spreadsheet_controller_for_checker.html',1,'usecasesmarker::spreadsheet_controller_for_checker']]]
];
