var searchData=
[
  ['create_5fspreadsheet_5fcontroller_0',['create_spreadsheet_controller',['../classusecasesmarker_1_1spread__sheet__factory__for__checker_1_1_spread_sheet_factory_for_checker.html#a0ea82925cde9865dd0852ac788921780',1,'usecasesmarker::spread_sheet_factory_for_checker::SpreadSheetFactoryForChecker']]]
];
