var searchData=
[
  ['load_5fspreadsheet_5ffrom_5ffile_0',['load_spreadsheet_from_file',['../classusecasesmarker_1_1spreadsheet__controller__for__checker_1_1_i_spreadsheet_controller_for_checker.html#a2ce267fead9f72c3afe25dabe2053d94',1,'usecasesmarker::spreadsheet_controller_for_checker::ISpreadsheetControllerForChecker']]]
];
