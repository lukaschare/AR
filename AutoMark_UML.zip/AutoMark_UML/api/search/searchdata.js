var indexSectionsWithContent =
{
  0: "cgilrs",
  1: "irs",
  2: "cgls"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

